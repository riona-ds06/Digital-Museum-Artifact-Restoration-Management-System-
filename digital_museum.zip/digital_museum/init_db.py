"""Creates (or re-creates) the database, tables, sample data, triggers, functions and procedures.

    python init_db.py
WARNING: drops the database named in config.py first, so you always get a clean demo state."""
import os
import sys

import pymysql
from werkzeug.security import generate_password_hash

import config
from sqlsplit import split_blocks, split_statements

HERE = os.path.dirname(os.path.abspath(__file__))


def read(name):
    with open(os.path.join(HERE, "sql", name), encoding="utf-8") as f:
        return f.read()


def main():
    try:
        conn = pymysql.connect(host=config.DB_HOST, port=config.DB_PORT, user=config.DB_USER,
                               password=config.DB_PASSWORD, charset="utf8mb4", autocommit=True)
    except pymysql.MySQLError as e:
        print("\nCould not connect to MySQL:", e)
        print("Check that MySQL is running and that user/password in config.py are correct.")
        sys.exit(1)

    cur = conn.cursor()
    db = config.DB_NAME
    print(f"Creating database `{db}` ...")
    cur.execute(f"DROP DATABASE IF EXISTS `{db}`")
    cur.execute(f"CREATE DATABASE `{db}` CHARACTER SET utf8mb4")
    cur.execute(f"USE `{db}`")

    for fname in ("schema.sql", "data.sql"):
        stmts = split_statements(read(fname))
        print(f"Running {fname} ({len(stmts)} statements) ...")
        for s in stmts:
            cur.execute(s)

    # Replace placeholder password hashes ("hash_anita123") with real salted hashes.
    cur.execute("SELECT staff_id, password_hash FROM STAFF")
    for staff_id, ph in cur.fetchall():
        plain = ph[len("hash_"):] if ph.startswith("hash_") else ph
        cur.execute("UPDATE STAFF SET password_hash=%s WHERE staff_id=%s",
                    (generate_password_hash(plain), staff_id))

    blocks = split_blocks(read("routines.sql"))
    print(f"Creating triggers/functions/procedures ({len(blocks)}) ...")
    for b in blocks:
        try:
            cur.execute(b)
        except pymysql.MySQLError as e:
            print("\nFailed on:\n", b[:200], "\n", e)
            if "log_bin_trust_function_creators" in str(e):
                print("Fix: run  SET GLOBAL log_bin_trust_function_creators = 1;  as root, then re-run.")
            sys.exit(1)

    conn.close()
    print("\nDone. Start the app with:  python app.py")
    print("Login example -> username: anita.rao   password: anita123")


if __name__ == "__main__":
    main()
