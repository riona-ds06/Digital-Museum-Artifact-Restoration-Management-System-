# Digital Museum Management System
DBMS mini project - Flask (Python) backend + plain HTML/CSS/JS frontend + MySQL.

## 1. Requirements
* Python 3.9+      (check: `python --version`)
* MySQL Server 8.x (running; you need the root password)

## 2. Setup (one time)
```
cd digital_museum
pip install -r requirements.txt
```
Open `config.py` and set `DB_PASSWORD` to your MySQL password
(or set the environment variable `MUSEUM_DB_PASSWORD`).

## 3. Create the database
```
python init_db.py
```
This DROPS and re-creates `digital_museum_db`: 17 tables, sample data, 4 triggers,
2 functions and 2 stored procedures. Run it again any time to reset the demo data.

If it says `log_bin_trust_function_creators`, run this once in the MySQL shell as root and retry:
```
SET GLOBAL log_bin_trust_function_creators = 1;
```

## 4. Run the app
```
python app.py
```
Open http://localhost:5000 and log in with a staff account from the STAFF table:

| Username | Password |
|---|---|
| anita.rao | anita123 |
| rahul.sharma | rahul123 |
| kiran.kumar | kiran123 |

(every staff member: `<firstname>123`; new staff added in the app get the password you type.)

## 5. Features
* **Login** with STAFF username/password (salted hashes, session based)
* **Dashboard** - counts, total/average value, charts (GROUP BY queries)
* **Artifacts** - search/filter, age via `fn_artifact_age`, cost via `fn_total_restoration_cost`,
  detail view with restoration projects (procedure), experts, materials, assessments, history, display, media
* **Manage Data** - add / edit / delete / search / sort / paginate for ALL 17 tables,
  foreign keys are dropdowns, DB errors (FK, UNIQUE, trigger) are shown in the form
* **Reports** - 18 SQL queries (WHERE, ORDER BY, GROUP BY, HAVING, aggregates, joins, nested/correlated subqueries); the SQL is shown
* **DB Features** - call both stored procedures; try both triggers (test rows are rolled back)

## 6. Files
```
app.py          Flask backend (REST API)       init_db.py   builds the database
config.py       DB settings                    sqlsplit.py  SQL file splitter
sql/schema.sql  DDL      sql/data.sql  DML     sql/routines.sql  triggers/functions/procedures
static/         index.html, style.css, app.js  (frontend)
```

## 7. Changes made to your original SQL
* `CREATOR.birth_year` is `INT` in the CREATE (YEAR cannot store 1100 etc.)
* `CREATOR`, `EXHIBITION`, `ARTIFACT_MEDIA` ids are `AUTO_INCREMENT` (so the app can add rows)
* `DISPLAY`, `PROJECT_EXPERT`, `PROJECT_MATERIAL` got composite primary keys (no duplicate rows)
* Functions use `READS SQL DATA` instead of `DETERMINISTIC`
* Added BEFORE UPDATE versions of the material and exhibition triggers
* The deliberately failing trigger test insert is not in data.sql (it is a button on the DB Features page)
