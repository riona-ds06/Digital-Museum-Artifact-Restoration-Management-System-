"""Database settings. Edit the defaults below, or set environment variables
(MUSEUM_DB_HOST, MUSEUM_DB_PORT, MUSEUM_DB_USER, MUSEUM_DB_PASSWORD, MUSEUM_DB_NAME)."""
import os

DB_HOST = os.environ.get("MUSEUM_DB_HOST", "localhost")
DB_PORT = int(os.environ.get("MUSEUM_DB_PORT", "3306"))
DB_USER = os.environ.get("MUSEUM_DB_USER", "root")
DB_PASSWORD = os.environ.get("MUSEUM_DB_PASSWORD", "")      # <-- put your MySQL root password here
DB_NAME = os.environ.get("MUSEUM_DB_NAME", "digital_museum_db")

SECRET_KEY = os.environ.get("MUSEUM_SECRET_KEY", "change-this-secret-for-real-use")
PORT = int(os.environ.get("PORT", "5000"))
