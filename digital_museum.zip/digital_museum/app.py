"""Digital Museum - Flask backend.  Run:  python app.py   then open http://localhost:5000"""
import datetime
import decimal
import functools

import pymysql
from flask import Flask, jsonify, request, send_from_directory, session
from flask.json.provider import DefaultJSONProvider
from werkzeug.security import check_password_hash, generate_password_hash

import config

PAGE_SIZE = 15


class MuseumJSON(DefaultJSONProvider):
    @staticmethod
    def default(o):
        if isinstance(o, decimal.Decimal):
            return float(o)
        if isinstance(o, (datetime.datetime, datetime.date)):
            return o.isoformat(sep=" ") if isinstance(o, datetime.datetime) else o.isoformat()
        if isinstance(o, datetime.timedelta):
            s = int(o.total_seconds())
            return f"{s // 3600:02d}:{s % 3600 // 60:02d}:{s % 60:02d}"
        return DefaultJSONProvider.default(o)


app = Flask(__name__, static_folder="static", static_url_path="")
app.json = MuseumJSON(app)
app.secret_key = config.SECRET_KEY


# ---------------------------------------------------------------- database helpers
def connect(autocommit=True):
    return pymysql.connect(host=config.DB_HOST, port=config.DB_PORT, user=config.DB_USER,
                           password=config.DB_PASSWORD, database=config.DB_NAME, charset="utf8mb4",
                           cursorclass=pymysql.cursors.DictCursor, autocommit=autocommit)


def query(sql, args=None, one=False):
    conn = connect()
    try:
        with conn.cursor() as cur:
            cur.execute(sql, args)
            rows = cur.fetchall()
            return (rows[0] if rows else None) if one else list(rows)
    finally:
        conn.close()


def execute(sql, args=None):
    conn = connect()
    try:
        with conn.cursor() as cur:
            cur.execute(sql, args)
            return cur.lastrowid, cur.rowcount
    finally:
        conn.close()


_meta_cache = {}


def list_tables():
    rows = query("SELECT TABLE_NAME AS t FROM information_schema.TABLES "
                 "WHERE TABLE_SCHEMA=%s AND TABLE_TYPE='BASE TABLE' ORDER BY TABLE_NAME", (config.DB_NAME,))
    return [r["t"] for r in rows]


def resolve_table(name):
    """Whitelist: only real tables of this schema (case-insensitive match)."""
    for t in list_tables():
        if t.lower() == (name or "").lower():
            return t
    return None


READONLY = {"restoration_material": {"total_cost"}}      # columns computed by triggers
HIDDEN = {"staff": {"password_hash"}}                     # never sent to the browser


def input_type(dtype):
    return {"int": "number", "bigint": "number", "smallint": "number", "year": "number",
            "decimal": "decimal", "date": "date", "datetime": "datetime", "timestamp": "datetime",
            "time": "time", "text": "textarea"}.get(dtype, "text")


def table_meta(table):
    key = table.lower()
    if key in _meta_cache:
        return _meta_cache[key]
    cols = query("SELECT COLUMN_NAME AS name, DATA_TYPE AS dtype, IS_NULLABLE AS nullable, COLUMN_KEY AS ckey, "
                 "EXTRA AS extra, COLUMN_DEFAULT AS dflt FROM information_schema.COLUMNS "
                 "WHERE TABLE_SCHEMA=%s AND TABLE_NAME=%s ORDER BY ORDINAL_POSITION", (config.DB_NAME, table))
    fks = query("SELECT COLUMN_NAME AS col, REFERENCED_TABLE_NAME AS rtable, REFERENCED_COLUMN_NAME AS rcol "
                "FROM information_schema.KEY_COLUMN_USAGE WHERE TABLE_SCHEMA=%s AND TABLE_NAME=%s "
                "AND REFERENCED_TABLE_NAME IS NOT NULL", (config.DB_NAME, table))
    fkmap = {f["col"]: {"table": f["rtable"], "column": f["rcol"]} for f in fks}
    out = []
    for c in cols:
        if c["name"] in HIDDEN.get(key, ()):
            continue
        out.append({"name": c["name"], "dtype": c["dtype"], "input": input_type(c["dtype"]),
                    "required": c["nullable"] == "NO" and c["dflt"] is None and "auto_increment" not in (c["extra"] or ""),
                    "pk": c["ckey"] == "PRI", "auto": "auto_increment" in (c["extra"] or ""),
                    "fk": fkmap.get(c["name"]), "readonly": c["name"] in READONLY.get(key, ())})
    meta = {"table": table, "columns": out, "pk": [c["name"] for c in out if c["pk"]],
            "has_password": key == "staff"}
    _meta_cache[key] = meta
    return meta


def clean(col, value):
    """Convert form value to something MySQL accepts (empty -> NULL)."""
    if value is None or (isinstance(value, str) and value.strip() == ""):
        return None
    if col["input"] == "datetime" and isinstance(value, str):
        return value.replace("T", " ")
    return value


def db_error(e):
    msg = e.args[1] if len(e.args) > 1 else str(e)
    return jsonify(error=str(msg)), 400


def login_required(fn):
    @functools.wraps(fn)
    def wrapper(*a, **kw):
        if "staff" not in session:
            return jsonify(error="Please log in."), 401
        return fn(*a, **kw)
    return wrapper


# ---------------------------------------------------------------- pages + auth
@app.route("/")
def index():
    return send_from_directory(app.static_folder, "index.html")


@app.route("/api/login", methods=["POST"])
def login():
    d = request.get_json(force=True) or {}
    try:
        row = query("SELECT staff_id, staff_name, designation, password_hash, staff_status FROM STAFF "
                    "WHERE username=%s", (d.get("username", "").strip(),), one=True)
    except pymysql.MySQLError as e:
        return jsonify(error="Database error: " + str(e)), 500
    if not row or not check_password_hash(row["password_hash"], d.get("password", "")):
        return jsonify(error="Invalid username or password."), 401
    if row["staff_status"] != "Active":
        return jsonify(error="This staff account is not active."), 403
    session["staff"] = {"id": row["staff_id"], "name": row["staff_name"], "designation": row["designation"]}
    return jsonify(session["staff"])


@app.route("/api/logout", methods=["POST"])
def logout():
    session.clear()
    return jsonify(ok=True)


@app.route("/api/me")
def me():
    if "staff" not in session:
        return jsonify(error="Not logged in"), 401
    return jsonify(session["staff"])


# ---------------------------------------------------------------- generic CRUD
@app.route("/api/tables")
@login_required
def tables():
    out = []
    for t in list_tables():
        n = query(f"SELECT COUNT(*) AS n FROM `{t}`", one=True)["n"]
        out.append({"name": t, "rows": n})
    return jsonify(out)


@app.route("/api/tables/<name>/meta")
@login_required
def meta(name):
    t = resolve_table(name)
    if not t:
        return jsonify(error="Unknown table"), 404
    return jsonify(table_meta(t))


@app.route("/api/tables/<name>", methods=["GET"])
@login_required
def rows(name):
    t = resolve_table(name)
    if not t:
        return jsonify(error="Unknown table"), 404
    m = table_meta(t)
    names = [c["name"] for c in m["columns"]]
    search = request.args.get("search", "").strip()
    sort = request.args.get("sort") if request.args.get("sort") in names else (m["pk"][0] if m["pk"] else names[0])
    direction = "DESC" if request.args.get("dir") == "desc" else "ASC"
    page = max(int(request.args.get("page", 1) or 1), 1)
    collist = ", ".join(f"`{n}`" for n in names)
    where, args = "", []
    if search:
        where = " WHERE CONCAT_WS(' ', " + ", ".join(f"`{n}`" for n in names) + ") LIKE %s"
        args.append(f"%{search}%")
    try:
        total = query(f"SELECT COUNT(*) AS n FROM `{t}`{where}", args, one=True)["n"]
        data = query(f"SELECT {collist} FROM `{t}`{where} ORDER BY `{sort}` {direction} LIMIT %s OFFSET %s",
                     args + [PAGE_SIZE, (page - 1) * PAGE_SIZE])
    except pymysql.MySQLError as e:
        return db_error(e)
    return jsonify(rows=data, total=total, page=page, pages=max((total + PAGE_SIZE - 1) // PAGE_SIZE, 1))


@app.route("/api/tables/<name>", methods=["POST"])
@login_required
def insert_row(name):
    t = resolve_table(name)
    if not t:
        return jsonify(error="Unknown table"), 404
    m = table_meta(t)
    d = request.get_json(force=True) or {}
    cols, vals = [], []
    for c in m["columns"]:
        if c["auto"] and not d.get(c["name"]):
            continue
        if c["readonly"]:
            cols.append(c["name"]); vals.append(0)        # trigger overwrites this
            continue
        if c["name"] in d:
            cols.append(c["name"]); vals.append(clean(c, d[c["name"]]))
    if m["has_password"]:
        pw = d.get("password", "")
        if not pw:
            return jsonify(error="Password is required for new staff."), 400
        cols.append("password_hash"); vals.append(generate_password_hash(pw))
    sql = f"INSERT INTO `{t}` ({', '.join('`'+c+'`' for c in cols)}) VALUES ({', '.join(['%s']*len(cols))})"
    try:
        new_id, _ = execute(sql, vals)
    except pymysql.MySQLError as e:
        return db_error(e)
    return jsonify(ok=True, id=new_id)


@app.route("/api/tables/<name>", methods=["PUT"])
@login_required
def update_row(name):
    t = resolve_table(name)
    if not t:
        return jsonify(error="Unknown table"), 404
    m = table_meta(t)
    body = request.get_json(force=True) or {}
    key, d = body.get("key", {}), body.get("data", {})
    if not m["pk"] or set(key) != set(m["pk"]):
        return jsonify(error="Row key missing."), 400
    sets, vals = [], []
    for c in m["columns"]:
        if c["pk"] or c["readonly"] or c["name"] not in d:
            continue
        sets.append(f"`{c['name']}`=%s"); vals.append(clean(c, d[c["name"]]))
    if m["has_password"] and d.get("password"):
        sets.append("`password_hash`=%s"); vals.append(generate_password_hash(d["password"]))
    if not sets:
        return jsonify(error="Nothing to update."), 400
    where = " AND ".join(f"`{k}`=%s" for k in m["pk"])
    try:
        execute(f"UPDATE `{t}` SET {', '.join(sets)} WHERE {where}", vals + [key[k] for k in m["pk"]])
    except pymysql.MySQLError as e:
        return db_error(e)
    return jsonify(ok=True)


@app.route("/api/tables/<name>", methods=["DELETE"])
@login_required
def delete_row(name):
    t = resolve_table(name)
    if not t:
        return jsonify(error="Unknown table"), 404
    m = table_meta(t)
    key = (request.get_json(force=True) or {}).get("key", {})
    if not m["pk"] or set(key) != set(m["pk"]):
        return jsonify(error="Row key missing."), 400
    where = " AND ".join(f"`{k}`=%s" for k in m["pk"])
    try:
        _, n = execute(f"DELETE FROM `{t}` WHERE {where}", [key[k] for k in m["pk"]])
    except pymysql.MySQLError as e:
        return db_error(e)
    return jsonify(ok=True, deleted=n)


@app.route("/api/fk/<name>/<col>")
@login_required
def fk_options(name, col):
    """Dropdown options for a foreign-key column."""
    t = resolve_table(name)
    if not t:
        return jsonify(error="Unknown table"), 404
    c = next((c for c in table_meta(t)["columns"] if c["name"] == col and c["fk"]), None)
    if not c:
        return jsonify(error="Not a foreign key"), 404
    rt = resolve_table(c["fk"]["table"])
    rm = table_meta(rt)
    label = next((x["name"] for x in rm["columns"] if x["dtype"] == "varchar" and not x["pk"]
                  and "email" not in x["name"] and "phone" not in x["name"]), None)
    idc = c["fk"]["column"]
    sql = f"SELECT `{idc}` AS value, " + (f"`{label}` AS label" if label else f"`{idc}` AS label") + f" FROM `{rt}` ORDER BY `{idc}`"
    out = [{"value": r["value"], "label": f"{r['value']} - {r['label']}" if label else str(r["value"])} for r in query(sql)]
    return jsonify(out)


# ---------------------------------------------------------------- dashboard
@app.route("/api/dashboard")
@login_required
def dashboard():
    one = lambda sql: query(sql, one=True)
    counts = one("SELECT (SELECT COUNT(*) FROM MUSEUM) museums, (SELECT COUNT(*) FROM COLLECTION) collections, "
                 "(SELECT COUNT(*) FROM ARTIFACT) artifacts, (SELECT COUNT(*) FROM CREATOR) creators, "
                 "(SELECT COUNT(*) FROM STAFF) staff, (SELECT COUNT(*) FROM EXHIBITION) exhibitions, "
                 "(SELECT COUNT(*) FROM EXHIBITION WHERE status='Active') active_exhibitions, "
                 "(SELECT COUNT(*) FROM VISITOR) visitors, (SELECT COUNT(*) FROM VISIT_RECORD) visits, "
                 "(SELECT COUNT(*) FROM RESTORATION_PROJECT) projects")
    money = one("SELECT COALESCE(SUM(estimated_value),0) total_value, COALESCE(AVG(estimated_value),0) avg_value FROM ARTIFACT")
    return jsonify(
        counts=counts, money=money,
        by_status=query("SELECT status AS label, COUNT(*) AS value FROM ARTIFACT GROUP BY status ORDER BY value DESC"),
        by_type=query("SELECT artifact_type AS label, COUNT(*) AS value FROM ARTIFACT GROUP BY artifact_type ORDER BY value DESC"),
        visits_by_museum=query("SELECT m.museum_name AS label, COUNT(v.visit_id) AS value FROM MUSEUM m "
                               "LEFT JOIN VISIT_RECORD v ON v.museum_id=m.museum_id GROUP BY m.museum_id, m.museum_name ORDER BY value DESC"),
        project_cost=query("SELECT status AS label, SUM(cost) AS value FROM RESTORATION_PROJECT GROUP BY status ORDER BY value DESC"),
        top_artifacts=query("SELECT artifact_id, artifact_name, estimated_value FROM ARTIFACT ORDER BY estimated_value DESC LIMIT 5"),
    )


# ---------------------------------------------------------------- artifact explorer (functions + procedures)
@app.route("/api/artifacts/overview")
@login_required
def artifacts_overview():
    q, status = request.args.get("q", "").strip(), request.args.get("status", "").strip()
    sql = ("SELECT a.artifact_id, a.accession_number, a.artifact_name, a.artifact_type, a.status, a.estimated_value, "
           "c.collection_name, m.museum_name, cr.creator_name, "
           "fn_artifact_age(a.artifact_id) AS age_years, fn_total_restoration_cost(a.artifact_id) AS restoration_cost "
           "FROM ARTIFACT a JOIN COLLECTION c ON a.collection_id=c.collection_id "
           "JOIN MUSEUM m ON c.museum_id=m.museum_id LEFT JOIN CREATOR cr ON a.creator_id=cr.creator_id WHERE 1=1")
    args = []
    if q:
        sql += " AND CONCAT_WS(' ', a.artifact_name, a.accession_number, a.artifact_type, a.origin_place, cr.creator_name) LIKE %s"
        args.append(f"%{q}%")
    if status:
        sql += " AND a.status=%s"; args.append(status)
    sql += " ORDER BY a.artifact_id"
    try:
        return jsonify(query(sql, args))
    except pymysql.MySQLError as e:
        return db_error(e)


@app.route("/api/artifacts/<int:aid>")
@login_required
def artifact_detail(aid):
    a = query("SELECT a.*, c.collection_name, m.museum_name, cr.creator_name, "
              "fn_artifact_age(a.artifact_id) AS age_years, fn_total_restoration_cost(a.artifact_id) AS restoration_cost "
              "FROM ARTIFACT a JOIN COLLECTION c ON a.collection_id=c.collection_id "
              "JOIN MUSEUM m ON c.museum_id=m.museum_id LEFT JOIN CREATOR cr ON a.creator_id=cr.creator_id "
              "WHERE a.artifact_id=%s", (aid,), one=True)
    if not a:
        return jsonify(error="Artifact not found"), 404
    projects = query("CALL sp_artifact_restoration_projects(%s)", (aid,))
    for p in projects:
        p["experts"] = query("SELECT e.expert_name, e.hours_worked FROM PROJECT_EXPERT pe "
                             "JOIN RESTORATION_EXPERT e ON e.expert_id=pe.expert_id WHERE pe.project_id=%s", (p["project_id"],))
        p["materials"] = query("SELECT mt.material_name, mt.quantity_used, mt.unit, mt.total_cost FROM PROJECT_MATERIAL pm "
                               "JOIN RESTORATION_MATERIAL mt ON mt.material_id=pm.material_id WHERE pm.project_id=%s", (p["project_id"],))
    return jsonify(
        artifact=a, projects=projects,
        media=query("SELECT m.media_type, m.file_name, m.file_url, m.description, m.uploaded_on, s.staff_name AS uploaded_by "
                    "FROM ARTIFACT_MEDIA m LEFT JOIN STAFF s ON s.staff_id=m.staff_id WHERE m.artifact_id=%s", (aid,)),
        history=query("SELECT h.event_date, h.event_type, h.location, h.description, h.source_reference, s.staff_name "
                      "FROM ARTIFACT_HISTORY h LEFT JOIN STAFF s ON s.staff_id=h.staff_id WHERE h.artifact_id=%s ORDER BY h.event_date", (aid,)),
        assessments=query("SELECT ca.assessment_date, ca.conditions, ca.damage_type, ca.damage_description, ca.recommended_action, "
                          "ca.priority, s.staff_name FROM CONDITION_ASSESSMENT ca LEFT JOIN STAFF s ON s.staff_id=ca.staff_id "
                          "WHERE ca.artifact_id=%s ORDER BY ca.assessment_date", (aid,)),
        displays=query("SELECT e.exhibition_name, d.display_location, d.display_case, d.display_start_date, d.display_end_date "
                       "FROM DISPLAY d JOIN EXHIBITION e ON e.exhibition_id=d.exhibition_id WHERE d.artifact_id=%s", (aid,)),
    )


@app.route("/api/procedures/by-status")
@login_required
def proc_by_status():
    try:
        return jsonify(query("CALL sp_artifacts_by_status(%s)", (request.args.get("status", ""),)))
    except pymysql.MySQLError as e:
        return db_error(e)


@app.route("/api/procedures/restoration-projects")
@login_required
def proc_projects():
    try:
        return jsonify(query("CALL sp_artifact_restoration_projects(%s)", (int(request.args.get("artifact_id", 0)),)))
    except (pymysql.MySQLError, ValueError) as e:
        return db_error(e) if isinstance(e, pymysql.MySQLError) else (jsonify(error="artifact_id must be a number"), 400)


@app.route("/api/statuses")
@login_required
def statuses():
    return jsonify([r["status"] for r in query("SELECT DISTINCT status FROM ARTIFACT WHERE status IS NOT NULL ORDER BY status")])


# ---------------------------------------------------------------- report queries
REPORTS = [
    {"id": "high-value", "title": "Artifacts worth more than 3,00,000", "kind": "SELECT + WHERE",
     "sql": "SELECT artifact_id, artifact_name, estimated_value FROM ARTIFACT WHERE estimated_value > 300000 ORDER BY estimated_value DESC"},
    {"id": "creators-oldest", "title": "Creators ordered by birth year", "kind": "ORDER BY",
     "sql": "SELECT creator_id, creator_name, birth_year FROM CREATOR ORDER BY birth_year ASC"},
    {"id": "count-by-type", "title": "Artifacts per type", "kind": "GROUP BY + COUNT",
     "sql": "SELECT artifact_type, COUNT(*) AS total_artifacts FROM ARTIFACT GROUP BY artifact_type ORDER BY total_artifacts DESC"},
    {"id": "types-multiple", "title": "Types with more than one artifact", "kind": "GROUP BY + HAVING",
     "sql": "SELECT artifact_type, COUNT(*) AS total_artifacts FROM ARTIFACT GROUP BY artifact_type HAVING COUNT(*) > 1"},
    {"id": "totals", "title": "Total, average, min and max value", "kind": "Aggregate functions",
     "sql": "SELECT COUNT(*) AS total_artifacts, AVG(estimated_value) AS average_value, MIN(estimated_value) AS min_value, MAX(estimated_value) AS max_value, SUM(estimated_value) AS total_value FROM ARTIFACT"},
    {"id": "join-collection", "title": "Artifacts with their collection and museum", "kind": "INNER JOIN (3 tables)",
     "sql": "SELECT a.artifact_id, a.artifact_name, c.collection_name, m.museum_name FROM ARTIFACT a INNER JOIN COLLECTION c ON a.collection_id=c.collection_id INNER JOIN MUSEUM m ON c.museum_id=m.museum_id ORDER BY a.artifact_id"},
    {"id": "above-average", "title": "Artifacts worth more than the average", "kind": "Nested query",
     "sql": "SELECT artifact_id, artifact_name, estimated_value FROM ARTIFACT WHERE estimated_value > (SELECT AVG(estimated_value) FROM ARTIFACT) ORDER BY estimated_value DESC"},
    {"id": "most-valuable", "title": "Most valuable artifact", "kind": "Nested query (MAX)",
     "sql": "SELECT artifact_id, artifact_name, estimated_value FROM ARTIFACT WHERE estimated_value = (SELECT MAX(estimated_value) FROM ARTIFACT)"},
    {"id": "no-restoration", "title": "Damaged / needing-restoration artifacts with NO restoration project", "kind": "LEFT JOIN + IS NULL",
     "sql": "SELECT a.artifact_id, a.artifact_name, a.status FROM ARTIFACT a LEFT JOIN RESTORATION_PROJECT p ON p.artifact_id=a.artifact_id WHERE a.status IN ('Damaged','Needs Restoration') AND p.project_id IS NULL"},
    {"id": "project-cost", "title": "Restoration cost per museum", "kind": "Multi-table JOIN + SUM",
     "sql": "SELECT m.museum_name, COUNT(p.project_id) AS projects, SUM(p.cost) AS total_cost FROM RESTORATION_PROJECT p JOIN ARTIFACT a ON a.artifact_id=p.artifact_id JOIN COLLECTION c ON c.collection_id=a.collection_id JOIN MUSEUM m ON m.museum_id=c.museum_id GROUP BY m.museum_id, m.museum_name ORDER BY total_cost DESC"},
    {"id": "expert-hours", "title": "Experts per project and their hours", "kind": "Many-to-many JOIN",
     "sql": "SELECT p.project_name, COUNT(pe.expert_id) AS experts, SUM(e.hours_worked) AS total_hours FROM RESTORATION_PROJECT p JOIN PROJECT_EXPERT pe ON pe.project_id=p.project_id JOIN RESTORATION_EXPERT e ON e.expert_id=pe.expert_id GROUP BY p.project_id, p.project_name ORDER BY total_hours DESC"},
    {"id": "material-cost", "title": "Material cost per project", "kind": "Many-to-many JOIN + SUM",
     "sql": "SELECT p.project_name, COUNT(m.material_id) AS materials, SUM(m.total_cost) AS material_cost, p.cost AS project_cost FROM RESTORATION_PROJECT p JOIN PROJECT_MATERIAL pm ON pm.project_id=p.project_id JOIN RESTORATION_MATERIAL m ON m.material_id=pm.material_id GROUP BY p.project_id, p.project_name, p.cost ORDER BY material_cost DESC"},
    {"id": "exhibition-artifacts", "title": "Artifacts on display per exhibition", "kind": "LEFT JOIN + COUNT",
     "sql": "SELECT e.exhibition_name, e.status, COUNT(d.artifact_id) AS artifacts_on_display FROM EXHIBITION e LEFT JOIN DISPLAY d ON d.exhibition_id=e.exhibition_id GROUP BY e.exhibition_id, e.exhibition_name, e.status ORDER BY artifacts_on_display DESC"},
    {"id": "visits-museum", "title": "Visits and average stay per museum", "kind": "JOIN + AVG(TIME)",
     "sql": "SELECT m.museum_name, COUNT(*) AS visits, ROUND(AVG(TIME_TO_SEC(TIMEDIFF(v.exit_time, v.entry_time)))/60) AS avg_minutes FROM VISIT_RECORD v JOIN MUSEUM m ON m.museum_id=v.museum_id GROUP BY m.museum_id, m.museum_name ORDER BY visits DESC"},
    {"id": "visitor-nationality", "title": "Visitors by nationality", "kind": "GROUP BY",
     "sql": "SELECT nationality, COUNT(*) AS visitors, ROUND(AVG(age),1) AS avg_age FROM VISITOR GROUP BY nationality ORDER BY visitors DESC"},
    {"id": "repeat-visitors", "title": "Visitors who visited more than once", "kind": "Subquery with IN",
     "sql": "SELECT visitor_id, visitor_name, email FROM VISITOR WHERE visitor_id IN (SELECT visitor_id FROM VISIT_RECORD GROUP BY visitor_id HAVING COUNT(*) > 1)"},
    {"id": "staff-workload", "title": "Assessments done and projects managed per staff member", "kind": "Correlated subqueries",
     "sql": "SELECT s.staff_name, s.designation, (SELECT COUNT(*) FROM CONDITION_ASSESSMENT ca WHERE ca.staff_id=s.staff_id) AS assessments, (SELECT COUNT(*) FROM RESTORATION_PROJECT p WHERE p.manager_id=s.staff_id) AS projects_managed FROM STAFF s ORDER BY projects_managed DESC, assessments DESC"},
    {"id": "high-priority", "title": "High-priority assessments with artifact and assessor", "kind": "JOIN + WHERE",
     "sql": "SELECT a.artifact_name, ca.assessment_date, ca.conditions, ca.damage_type, ca.recommended_action, s.staff_name AS assessed_by FROM CONDITION_ASSESSMENT ca JOIN ARTIFACT a ON a.artifact_id=ca.artifact_id LEFT JOIN STAFF s ON s.staff_id=ca.staff_id WHERE ca.priority='High' ORDER BY ca.assessment_date"},
]


@app.route("/api/reports")
@login_required
def reports():
    return jsonify([{k: r[k] for k in ("id", "title", "kind")} for r in REPORTS])


@app.route("/api/reports/<rid>")
@login_required
def run_report(rid):
    r = next((r for r in REPORTS if r["id"] == rid), None)
    if not r:
        return jsonify(error="Unknown report"), 404
    try:
        return jsonify(title=r["title"], kind=r["kind"], sql=r["sql"], rows=query(r["sql"]))
    except pymysql.MySQLError as e:
        return db_error(e)


# ---------------------------------------------------------------- trigger demos (always rolled back)
def demo_tx(fn):
    conn = connect(autocommit=False)
    try:
        with conn.cursor() as cur:
            return fn(cur)
    finally:
        conn.rollback()
        conn.close()


@app.route("/api/demo/exhibition-trigger", methods=["POST"])
@login_required
def demo_exhibition():
    d = request.get_json(force=True) or {}

    def run(cur):
        try:
            cur.execute("INSERT INTO EXHIBITION (museum_id, exhibition_name, description, theme, start_date, end_date, status) "
                        "VALUES (%s, 'Trigger Demo Exhibition', 'Demo only', 'Test', %s, %s, 'Planned')",
                        (d.get("museum_id") or 1, d.get("start_date"), d.get("end_date")))
            return {"accepted": True, "message": "Row accepted by trigger (and rolled back - nothing was saved)."}
        except pymysql.MySQLError as e:
            return {"accepted": False, "message": e.args[1] if len(e.args) > 1 else str(e)}
    return jsonify(demo_tx(run))


@app.route("/api/demo/material-trigger", methods=["POST"])
@login_required
def demo_material():
    d = request.get_json(force=True) or {}

    def run(cur):
        try:
            cur.execute("INSERT INTO RESTORATION_MATERIAL (material_name, material_type, supplier, unit, unit_cost, quantity_used, total_cost) "
                        "VALUES ('Trigger Demo Material', 'Demo', 'Demo', 'kg', %s, %s, 0)",
                        (d.get("unit_cost") or 0, d.get("quantity_used") or 0))
            cur.execute("SELECT unit_cost, quantity_used, total_cost FROM RESTORATION_MATERIAL WHERE material_id=LAST_INSERT_ID()")
            return {"ok": True, "row": cur.fetchone()}
        except pymysql.MySQLError as e:
            return {"ok": False, "message": e.args[1] if len(e.args) > 1 else str(e)}
    return jsonify(demo_tx(run))


@app.errorhandler(pymysql.MySQLError)
def handle_mysql(e):
    return jsonify(error="Database error: " + str(e)), 500


if __name__ == "__main__":
    print(f"\nDigital Museum running at  http://localhost:{config.PORT}\n")
    app.run(host="127.0.0.1", port=config.PORT, debug=False)
