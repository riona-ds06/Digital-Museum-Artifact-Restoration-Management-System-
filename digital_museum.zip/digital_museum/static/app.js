/* Digital Museum - single page frontend (no libraries, works offline) */
const $ = (s, r = document) => r.querySelector(s);
const esc = v => String(v ?? "").replace(/[&<>"']/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
const title = s => s.replace(/_/g, " ").replace(/\b\w/g, c => c.toUpperCase());

let me = null;

async function api(path, opts = {}) {
  const init = { method: opts.method || "GET", headers: {} };
  if (opts.body !== undefined) { init.headers["Content-Type"] = "application/json"; init.body = JSON.stringify(opts.body); }
  const res = await fetch("/api" + path, init);
  let data = null;
  try { data = await res.json(); } catch (e) { /* empty */ }
  if (res.status === 401 && path !== "/login") { showLogin(); throw new Error("Please log in."); }
  if (!res.ok) throw new Error((data && data.error) || res.statusText);
  return data;
}

function toast(msg, bad = false) {
  const t = $("#toast");
  t.textContent = msg; t.className = bad ? "bad" : ""; t.hidden = false;
  clearTimeout(toast.h); toast.h = setTimeout(() => (t.hidden = true), 3500);
}

/* ---------- formatting helpers ---------- */
const BADGE_COLS = /^(status|priority|conditions|staff_status)$/;
const MONEY_COLS = /(value|cost|total_value|average_value|min_value|max_value)$/;
function fmt(v, key = "") {
  if (v === null || v === undefined) return '<span class="muted">—</span>';
  if (BADGE_COLS.test(key)) return `<span class="badge ${esc(v)}">${esc(v)}</span>`;
  if (typeof v === "number") {
    if (MONEY_COLS.test(key)) return "₹" + v.toLocaleString("en-IN", { maximumFractionDigits: 2 });
    return Number.isInteger(v) && /(_id|year)$/.test(key) ? String(v) : v.toLocaleString("en-IN", { maximumFractionDigits: 2 });
  }
  return esc(v);
}

function tableHTML(rows, opts = {}) {
  if (!rows || !rows.length) return '<p class="muted">No rows.</p>';
  const cols = opts.columns || Object.keys(rows[0]);
  return `<div class="table-wrap"><table><thead><tr>${cols.map(c => `<th data-col="${esc(c)}">${esc(title(c))}${opts.sort === c ? (opts.dir === "desc" ? " ▼" : " ▲") : ""}</th>`).join("")}${opts.actions ? "<th></th>" : ""}</tr></thead><tbody>` +
    rows.map((r, i) => `<tr>${cols.map(c => `<td class="${typeof r[c] === "number" ? "num" : ""}" title="${esc(r[c])}">${fmt(r[c], c)}</td>`).join("")}${opts.actions ? `<td class="actions">${opts.actions(r, i)}</td>` : ""}</tr>`).join("") +
    "</tbody></table></div>";
}

function bars(items, money = false) {
  if (!items.length) return '<p class="muted">No data.</p>';
  const max = Math.max(...items.map(i => Number(i.value)), 1);
  return items.map(i => `<div class="bar-row"><span class="lab" title="${esc(i.label)}">${esc(i.label ?? "—")}</span><div class="bar"><span style="width:${(Number(i.value) / max) * 100}%"></span></div><span class="val">${money ? "₹" + Number(i.value).toLocaleString("en-IN") : esc(i.value)}</span></div>`).join("");
}

/* ---------- modal ---------- */
function openModal(html, wide = false) {
  closeModal();
  const bg = document.createElement("div");
  bg.className = "modal-bg";
  bg.innerHTML = `<div class="modal ${wide ? "wide" : ""}">${html}</div>`;
  bg.addEventListener("mousedown", e => { if (e.target === bg) closeModal(); });
  $("#modal-root").appendChild(bg);
  return bg.firstElementChild;
}
function closeModal() { $("#modal-root").innerHTML = ""; }
document.addEventListener("keydown", e => { if (e.key === "Escape") closeModal(); });

/* ---------- auth ---------- */
function showLogin() { me = null; $("#app").hidden = true; $("#login-screen").hidden = false; }
async function showApp() {
  $("#login-screen").hidden = true; $("#app").hidden = false;
  $("#user-name").textContent = me.name; $("#user-role").textContent = me.designation || "";
  route();
}
$("#login-form").addEventListener("submit", async e => {
  e.preventDefault();
  const err = $("#login-error"); err.hidden = true;
  try {
    me = await api("/login", { method: "POST", body: { username: $("#login-user").value, password: $("#login-pass").value } });
    $("#login-pass").value = "";
    showApp();
  } catch (ex) { err.textContent = ex.message; err.hidden = false; }
});
$("#logout-btn").addEventListener("click", async () => { await api("/logout", { method: "POST" }).catch(() => {}); showLogin(); });

/* ---------- router ---------- */
const pages = { dashboard: pageDashboard, artifacts: pageArtifacts, data: pageData, reports: pageReports, features: pageFeatures };
function route() {
  const page = (location.hash.slice(1) || "dashboard").split("/")[0];
  const fn = pages[page] || pageDashboard;
  document.querySelectorAll("#nav a").forEach(a => a.classList.toggle("active", a.dataset.page === page));
  $("#main").innerHTML = '<p class="muted">Loading…</p>';
  fn().catch(e => { $("#main").innerHTML = `<div class="error">${esc(e.message)}</div>`; });
}
window.addEventListener("hashchange", () => { if (me) route(); });

/* ---------- dashboard ---------- */
async function pageDashboard() {
  const d = await api("/dashboard");
  const c = d.counts;
  const stat = (n, l) => `<div class="stat"><div class="n">${n}</div><div class="l">${l}</div></div>`;
  $("#main").innerHTML = `
    <div class="page-head"><h2>Dashboard</h2></div>
    <div class="cards">
      ${stat(c.museums, "Museums")}${stat(c.collections, "Collections")}${stat(c.artifacts, "Artifacts")}${stat(c.creators, "Creators")}
      ${stat(c.exhibitions + " <small class='muted'>(" + c.active_exhibitions + " active)</small>", "Exhibitions")}
      ${stat(c.staff, "Staff")}${stat(c.visitors, "Visitors")}${stat(c.visits, "Visits")}${stat(c.projects, "Restoration projects")}
      ${stat("₹" + Number(d.money.total_value).toLocaleString("en-IN"), "Total collection value")}
      ${stat("₹" + Math.round(d.money.avg_value).toLocaleString("en-IN"), "Average artifact value")}
    </div>
    <div class="grid2">
      <div class="panel"><h3>Artifacts by condition status</h3>${bars(d.by_status)}</div>
      <div class="panel"><h3>Artifacts by type</h3>${bars(d.by_type)}</div>
      <div class="panel"><h3>Visits per museum</h3>${bars(d.visits_by_museum)}</div>
      <div class="panel"><h3>Restoration cost by project status</h3>${bars(d.project_cost, true)}</div>
    </div>
    <div class="panel"><h3>Top 5 most valuable artifacts</h3>${tableHTML(d.top_artifacts)}</div>`;
}

/* ---------- artifacts explorer ---------- */
async function pageArtifacts() {
  const statuses = await api("/statuses");
  $("#main").innerHTML = `
    <div class="page-head"><h2>Artifacts</h2><span class="muted">Age uses <code>fn_artifact_age()</code>, restoration cost uses <code>fn_total_restoration_cost()</code></span></div>
    <div class="toolbar">
      <input type="search" id="a-q" placeholder="Search name, accession no, type, place, creator…">
      <select id="a-status"><option value="">All statuses</option>${statuses.map(s => `<option>${esc(s)}</option>`).join("")}</select>
    </div>
    <div id="a-table"></div>`;
  let timer;
  const load = async () => {
    const rows = await api(`/artifacts/overview?q=${encodeURIComponent($("#a-q").value)}&status=${encodeURIComponent($("#a-status").value)}`);
    $("#a-table").innerHTML = tableHTML(rows, {
      columns: ["artifact_id", "accession_number", "artifact_name", "artifact_type", "status", "estimated_value", "age_years", "restoration_cost", "collection_name", "museum_name", "creator_name"],
      actions: r => `<button class="btn small" data-id="${r.artifact_id}">Details</button>`
    });
    $("#a-table").querySelectorAll("button[data-id]").forEach(b => b.onclick = () => artifactDetail(b.dataset.id));
  };
  $("#a-q").oninput = () => { clearTimeout(timer); timer = setTimeout(load, 250); };
  $("#a-status").onchange = load;
  await load();
}

async function artifactDetail(id) {
  let d;
  try { d = await api("/artifacts/" + id); } catch (e) { return toast(e.message, true); }
  const a = d.artifact;
  const sec = (t, body) => `<div class="panel"><h3>${t}</h3>${body}</div>`;
  const projects = d.projects.length ? d.projects.map(p => `
      <div style="margin-bottom:12px"><b>${esc(p.project_name)}</b> ${fmt(p.status, "status")} — ${fmt(p.cost, "cost")}
      <div class="muted">${esc(p.objective)} (${esc(p.start_date)} → ${esc(p.end_date)})</div>
      <div><b>Experts:</b> ${p.experts.map(e => esc(e.expert_name) + " (" + e.hours_worked + "h)").join(", ") || "—"}</div>
      <div><b>Materials:</b> ${p.materials.map(m => esc(m.material_name) + " ×" + m.quantity_used + " " + esc(m.unit)).join(", ") || "—"}</div></div>`).join("") : '<p class="muted">No restoration projects.</p>';
  const m = openModal(`
    <div class="modal-head"><h2>${esc(a.artifact_name)} <small class="muted">${esc(a.accession_number)}</small></h2><button class="btn small" id="m-close">✕</button></div>
    <dl class="kv">
      <dt>Status</dt><dd>${fmt(a.status, "status")}</dd><dt>Type</dt><dd>${esc(a.artifact_type)}</dd>
      <dt>Collection</dt><dd>${esc(a.collection_name)} — ${esc(a.museum_name)}</dd><dt>Creator</dt><dd>${esc(a.creator_name || "Unknown")}</dd>
      <dt>Origin</dt><dd>${esc(a.origin_place)}</dd><dt>Created</dt><dd>${esc(a.creation_date)} (${a.age_years} years old)</dd>
      <dt>Acquired</dt><dd>${esc(a.acquisition_date)}</dd><dt>Estimated value</dt><dd>${fmt(a.estimated_value, "estimated_value")}</dd>
      <dt>Total restoration cost</dt><dd>${fmt(a.restoration_cost, "cost")}</dd><dt>Description</dt><dd>${esc(a.description)}</dd>
    </dl>
    ${sec("Restoration projects <small class='muted'>(sp_artifact_restoration_projects)</small>", projects)}
    ${sec("Condition assessments", tableHTML(d.assessments))}
    ${sec("History", tableHTML(d.history))}
    ${sec("Exhibitions / display", tableHTML(d.displays))}
    ${sec("Media", tableHTML(d.media))}`, true);
  $("#m-close", m).onclick = closeModal;
}

/* ---------- manage data (generic CRUD) ---------- */
const S = { table: null, meta: null, page: 1, search: "", sort: null, dir: "asc" };

async function pageData() {
  const tabs = await api("/tables");
  if (!S.table) S.table = tabs[0].name;
  $("#main").innerHTML = `
    <div class="page-head"><h2>Manage Data</h2></div>
    <div class="table-tabs">${tabs.map(t => `<span class="chip ${t.name === S.table ? "active" : ""}" data-t="${esc(t.name)}">${esc(title(t.name))} <small>${t.rows}</small></span>`).join("")}</div>
    <div class="toolbar"><input type="search" id="d-q" placeholder="Search in ${esc(title(S.table))}…" value="${esc(S.search)}"><button class="btn primary" id="d-add">＋ Add</button></div>
    <div id="d-table"></div><div class="pager" id="d-pager"></div>`;
  document.querySelectorAll(".chip").forEach(c => c.onclick = () => { S.table = c.dataset.t; S.page = 1; S.search = ""; S.sort = null; S.dir = "asc"; S.meta = null; pageData(); });
  let timer;
  $("#d-q").oninput = e => { clearTimeout(timer); timer = setTimeout(() => { S.search = e.target.value; S.page = 1; loadRows(); }, 250); };
  S.meta = await api(`/tables/${S.table}/meta`);
  $("#d-add").onclick = () => openForm(null);
  await loadRows();
}

async function loadRows() {
  const q = new URLSearchParams({ page: S.page, search: S.search, dir: S.dir });
  if (S.sort) q.set("sort", S.sort);
  let d;
  try { d = await api(`/tables/${S.table}?${q}`); } catch (e) { return toast(e.message, true); }
  const meta = S.meta, canEdit = meta.columns.some(c => !c.pk && !c.readonly);
  $("#d-table").innerHTML = tableHTML(d.rows, {
    columns: meta.columns.map(c => c.name), sort: S.sort || meta.pk[0], dir: S.dir,
    actions: (r, i) => `${canEdit ? `<button class="btn small" data-edit="${i}">Edit</button> ` : ""}<button class="btn small danger" data-del="${i}">Delete</button>`
  });
  if (!d.rows.length) $("#d-table").innerHTML = '<p class="muted">No rows found.</p>';
  $("#d-table").querySelectorAll("th[data-col]").forEach(th => th.onclick = () => {
    S.dir = (S.sort === th.dataset.col && S.dir === "asc") ? "desc" : "asc"; S.sort = th.dataset.col; loadRows();
  });
  $("#d-table").querySelectorAll("[data-edit]").forEach(b => b.onclick = () => openForm(d.rows[b.dataset.edit]));
  $("#d-table").querySelectorAll("[data-del]").forEach(b => b.onclick = () => delRow(d.rows[b.dataset.del]));
  $("#d-pager").innerHTML = `<button class="btn small" id="p-prev" ${d.page <= 1 ? "disabled" : ""}>◀ Prev</button><span>Page ${d.page} of ${d.pages} · ${d.total} rows</span><button class="btn small" id="p-next" ${d.page >= d.pages ? "disabled" : ""}>Next ▶</button>`;
  $("#p-prev").onclick = () => { S.page--; loadRows(); };
  $("#p-next").onclick = () => { S.page++; loadRows(); };
}

const keyOf = row => Object.fromEntries(S.meta.pk.map(k => [k, row[k]]));

async function delRow(row) {
  if (!confirm("Delete this row from " + title(S.table) + "?\nRows in other tables that depend on it may be deleted or blocked by foreign keys.")) return;
  try { await api(`/tables/${S.table}`, { method: "DELETE", body: { key: keyOf(row) } }); toast("Deleted"); await refreshTabsAndRows(); }
  catch (e) { toast(e.message, true); }
}
async function refreshTabsAndRows() { const keep = { ...S }; await pageData(); Object.assign(S, keep); }

async function openForm(row) {
  const meta = S.meta, editing = !!row;
  const fields = meta.columns.filter(c => !(c.auto && !editing) && !(c.readonly));
  const opts = {};
  await Promise.all(fields.filter(c => c.fk).map(async c => { opts[c.name] = await api(`/fk/${S.table}/${c.name}`); }));
  const input = c => {
    const val = editing ? row[c.name] : null, dis = editing && c.pk ? "disabled" : "";
    const v = val === null || val === undefined ? "" : String(val);
    const req = c.required ? "required" : "";
    if (c.fk) return `<select name="${c.name}" ${req} ${dis}><option value="">— select —</option>${opts[c.name].map(o => `<option value="${esc(o.value)}" ${String(o.value) === v ? "selected" : ""}>${esc(o.label)}</option>`).join("")}</select>`;
    if (c.input === "textarea") return `<textarea name="${c.name}" ${req}>${esc(v)}</textarea>`;
    const type = { number: "number", decimal: "number", date: "date", datetime: "datetime-local", time: "time" }[c.input] || "text";
    const step = c.input === "decimal" ? 'step="0.01"' : c.input === "time" || c.input === "datetime" ? 'step="1"' : "";
    return `<input name="${c.name}" type="${type}" ${step} value="${esc(c.input === "datetime" ? v.replace(" ", "T") : v)}" ${req} ${dis}>`;
  };
  let html = fields.map(c => `<label class="${c.input === "textarea" ? "full" : ""}">${esc(title(c.name))}${c.required ? ' <span class="req">*</span>' : ""}${input(c)}</label>`).join("");
  if (meta.has_password) html += `<label>Password${editing ? ' <span class="note">(leave blank to keep current)</span>' : ' <span class="req">*</span>'}<input name="password" type="password" ${editing ? "" : "required"} autocomplete="new-password"></label>`;
  const computed = meta.columns.filter(c => c.readonly).map(c => title(c.name));
  const m = openModal(`<form id="row-form"><div class="modal-head"><h2>${editing ? "Edit" : "Add"} — ${esc(title(S.table))}</h2><button type="button" class="btn small" id="m-close">✕</button></div>
    ${computed.length ? `<p class="note">${computed.join(", ")} is calculated automatically by a database trigger.</p>` : ""}
    <div class="form-grid">${html}</div><div id="form-error" class="error" style="margin-top:12px" hidden></div>
    <div class="modal-foot"><button type="button" class="btn" id="m-cancel">Cancel</button><button class="btn primary" type="submit">${editing ? "Save changes" : "Create"}</button></div></form>`);
  $("#m-close", m).onclick = $("#m-cancel", m).onclick = closeModal;
  $("#row-form", m).onsubmit = async e => {
    e.preventDefault();
    const data = {};
    new FormData(e.target).forEach((v, k) => (data[k] = v));
    e.target.querySelectorAll("input:disabled,select:disabled").forEach(el => delete data[el.name]);
    try {
      if (editing) await api(`/tables/${S.table}`, { method: "PUT", body: { key: keyOf(row), data } });
      else await api(`/tables/${S.table}`, { method: "POST", body: data });
      closeModal(); toast(editing ? "Saved" : "Created"); await refreshTabsAndRows();
    } catch (ex) { const er = $("#form-error", m); er.textContent = ex.message; er.hidden = false; }
  };
}

/* ---------- reports ---------- */
async function pageReports() {
  const list = await api("/reports");
  $("#main").innerHTML = `<div class="page-head"><h2>Reports (SQL queries)</h2><span class="muted">Click a report to run it and see the SQL behind it</span></div>
    <div class="report-list">${list.map(r => `<div class="report-item" data-id="${esc(r.id)}"><div class="k">${esc(r.kind)}</div><b>${esc(r.title)}</b></div>`).join("")}</div>`;
  document.querySelectorAll(".report-item").forEach(el => el.onclick = async () => {
    try {
      const r = await api("/reports/" + el.dataset.id);
      const m = openModal(`<div class="modal-head"><h2>${esc(r.title)}</h2><button class="btn small" id="m-close">✕</button></div>
        <div class="k muted">${esc(r.kind)} · ${r.rows.length} row(s)</div><div class="sqlbox">${esc(r.sql)}</div>${tableHTML(r.rows)}`, true);
      $("#m-close", m).onclick = closeModal;
    } catch (e) { toast(e.message, true); }
  });
}

/* ---------- DB features: procedures + triggers ---------- */
async function pageFeatures() {
  const [statuses, arts, museums] = await Promise.all([api("/statuses"), api("/artifacts/overview"), api("/tables/MUSEUM")]);
  $("#main").innerHTML = `
    <div class="page-head"><h2>Database Features</h2><span class="muted">Stored procedures and triggers from the SQL script</span></div>
    <div class="grid2">
      <div class="panel"><h3>Procedure: <code>sp_artifacts_by_status</code></h3>
        <div class="row"><label>Status<select id="f-status">${statuses.map(s => `<option>${esc(s)}</option>`).join("")}</select></label><button class="btn primary" id="f-status-go">CALL</button></div>
        <div id="f-status-out" style="margin-top:10px"></div></div>
      <div class="panel"><h3>Procedure: <code>sp_artifact_restoration_projects</code></h3>
        <div class="row"><label>Artifact<select id="f-art">${arts.map(a => `<option value="${a.artifact_id}">${a.artifact_id} - ${esc(a.artifact_name)}</option>`).join("")}</select></label><button class="btn primary" id="f-art-go">CALL</button></div>
        <div id="f-art-out" style="margin-top:10px"></div></div>
      <div class="panel"><h3>Trigger: <code>trg_exhibition_before_insert</code></h3>
        <p class="muted">Rejects an exhibition whose end date is before its start date. The test row is always rolled back.</p>
        <div class="row"><label>Museum<select id="t-museum">${museums.rows.map(m => `<option value="${m.museum_id}">${esc(m.museum_name)}</option>`).join("")}</select></label>
        <label>Start<input type="date" id="t-start" value="2026-12-01"></label><label>End<input type="date" id="t-end" value="2026-10-01"></label>
        <button class="btn primary" id="t-ex-go">Try insert</button></div><div id="t-ex-out" style="margin-top:10px"></div></div>
      <div class="panel"><h3>Trigger: <code>trg_material_before_insert</code></h3>
        <p class="muted">total_cost = unit_cost × quantity_used is computed automatically. The test row is rolled back.</p>
        <div class="row"><label>Unit cost<input type="number" id="t-uc" value="1500" step="0.01"></label><label>Quantity<input type="number" id="t-q" value="4" step="0.01"></label>
        <button class="btn primary" id="t-mat-go">Try insert</button></div><div id="t-mat-out" style="margin-top:10px"></div></div>
    </div>`;
  const safe = (btn, out, fn) => $(btn).onclick = async () => { try { $(out).innerHTML = await fn(); } catch (e) { $(out).innerHTML = `<div class="error">${esc(e.message)}</div>`; } };
  safe("#f-status-go", "#f-status-out", async () => tableHTML(await api("/procedures/by-status?status=" + encodeURIComponent($("#f-status").value))));
  safe("#f-art-go", "#f-art-out", async () => tableHTML(await api("/procedures/restoration-projects?artifact_id=" + $("#f-art").value)));
  safe("#t-ex-go", "#t-ex-out", async () => {
    const r = await api("/demo/exhibition-trigger", { method: "POST", body: { museum_id: $("#t-museum").value, start_date: $("#t-start").value, end_date: $("#t-end").value } });
    return `<span class="${r.accepted ? "result-ok" : "result-bad"}">${r.accepted ? "✔ " : "✘ Rejected: "}${esc(r.message)}</span>`;
  });
  safe("#t-mat-go", "#t-mat-out", async () => {
    const r = await api("/demo/material-trigger", { method: "POST", body: { unit_cost: $("#t-uc").value, quantity_used: $("#t-q").value } });
    if (!r.ok) return `<span class="result-bad">${esc(r.message)}</span>`;
    return `<span class="result-ok">total_cost = ${fmt(r.row.total_cost, "total_cost")}</span> (inserted with total_cost 0, trigger set ${r.row.unit_cost} × ${r.row.quantity_used})`;
  });
}

/* ---------- start ---------- */
(async () => {
  try { me = await api("/me"); showApp(); } catch (e) { showLogin(); }
})();
