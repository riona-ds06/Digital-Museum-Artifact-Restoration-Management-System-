@echo off
cd /d "%~dp0"
pip install -r requirements.txt
python init_db.py
python app.py
pause
