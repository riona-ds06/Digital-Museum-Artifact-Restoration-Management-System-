"""Tiny helpers to split .sql files into single statements (no external deps)."""
import re


def split_statements(text):
    """Split on ';' while respecting quotes and '--' comments."""
    stmts, buf, i, n = [], [], 0, len(text)
    quote = None
    while i < n:
        ch = text[i]
        if quote:
            buf.append(ch)
            if ch == "\\" and i + 1 < n:
                buf.append(text[i + 1]); i += 1
            elif ch == quote:
                if i + 1 < n and text[i + 1] == quote:   # doubled quote
                    buf.append(text[i + 1]); i += 1
                else:
                    quote = None
        elif ch in ("'", '"'):
            quote = ch; buf.append(ch)
        elif ch == "-" and text.startswith("--", i):
            j = text.find("\n", i)
            i = n if j == -1 else j
            continue
        elif ch == ";":
            s = "".join(buf).strip()
            if s:
                stmts.append(s)
            buf = []
        else:
            buf.append(ch)
        i += 1
    s = "".join(buf).strip()
    if s:
        stmts.append(s)
    return stmts


def split_blocks(text, marker="-- @@"):
    """Split on lines that start with the marker (used for triggers/functions/procedures)."""
    blocks = []
    for part in re.split(r"(?m)^" + re.escape(marker) + r".*$", text):
        lines = [l for l in part.splitlines() if not l.strip().startswith("--")]
        s = "\n".join(lines).strip()
        if s:
            blocks.append(s)
    return blocks
