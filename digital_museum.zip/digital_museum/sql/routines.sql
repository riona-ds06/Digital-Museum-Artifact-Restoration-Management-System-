-- Triggers, functions and procedures. Statements are separated by lines starting with "-- @@"
-- (so no DELIMITER commands are needed).

-- @@ trigger: material total cost on insert
CREATE TRIGGER trg_material_before_insert
BEFORE INSERT ON RESTORATION_MATERIAL
FOR EACH ROW
BEGIN
    SET NEW.total_cost = NEW.unit_cost * NEW.quantity_used;
END

-- @@ trigger: material total cost on update
CREATE TRIGGER trg_material_before_update
BEFORE UPDATE ON RESTORATION_MATERIAL
FOR EACH ROW
BEGIN
    SET NEW.total_cost = NEW.unit_cost * NEW.quantity_used;
END

-- @@ trigger: exhibition dates on insert
CREATE TRIGGER trg_exhibition_before_insert
BEFORE INSERT ON EXHIBITION
FOR EACH ROW
BEGIN
    IF NEW.end_date < NEW.start_date THEN
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = 'Exhibition end date cannot be before start date';
    END IF;
END

-- @@ trigger: exhibition dates on update
CREATE TRIGGER trg_exhibition_before_update
BEFORE UPDATE ON EXHIBITION
FOR EACH ROW
BEGIN
    IF NEW.end_date < NEW.start_date THEN
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = 'Exhibition end date cannot be before start date';
    END IF;
END

-- @@ function: artifact age
CREATE FUNCTION fn_artifact_age(p_artifact_id INT)
RETURNS INT
READS SQL DATA
BEGIN
    DECLARE v_age INT;
    SELECT TIMESTAMPDIFF(YEAR, creation_date, CURDATE())
    INTO v_age
    FROM ARTIFACT
    WHERE artifact_id = p_artifact_id;
    RETURN v_age;
END

-- @@ function: total restoration cost
CREATE FUNCTION fn_total_restoration_cost(p_artifact_id INT)
RETURNS DECIMAL(12,2)
READS SQL DATA
BEGIN
    DECLARE v_total DECIMAL(12,2);
    SELECT COALESCE(SUM(cost), 0.00)
    INTO v_total
    FROM RESTORATION_PROJECT
    WHERE artifact_id = p_artifact_id;
    RETURN v_total;
END

-- @@ procedure: artifacts by status
CREATE PROCEDURE sp_artifacts_by_status(IN p_status VARCHAR(50))
BEGIN
    SELECT artifact_id, artifact_name, artifact_type, estimated_value, status
    FROM ARTIFACT
    WHERE status = p_status
    ORDER BY artifact_name;
END

-- @@ procedure: restoration projects of an artifact
CREATE PROCEDURE sp_artifact_restoration_projects(IN p_artifact_id INT)
BEGIN
    SELECT project_id, project_name, objective, start_date, end_date, status, cost
    FROM RESTORATION_PROJECT
    WHERE artifact_id = p_artifact_id
    ORDER BY start_date;
END
