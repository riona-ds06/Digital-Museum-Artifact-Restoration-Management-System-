-- Run after schema.sql and data.sql using MySQL 8.
DELIMITER $$

CREATE TRIGGER trg_material_before_insert
BEFORE INSERT ON RESTORATION_MATERIAL
FOR EACH ROW
BEGIN
  SET NEW.total_cost = NEW.unit_cost * NEW.quantity_used;
END$$

CREATE TRIGGER trg_material_before_update
BEFORE UPDATE ON RESTORATION_MATERIAL
FOR EACH ROW
BEGIN
  SET NEW.total_cost = NEW.unit_cost * NEW.quantity_used;
END$$

CREATE TRIGGER trg_exhibition_before_insert
BEFORE INSERT ON EXHIBITION
FOR EACH ROW
BEGIN
  IF NEW.end_date < NEW.start_date THEN
    SIGNAL SQLSTATE '45000'
      SET MESSAGE_TEXT = 'Exhibition end date cannot be before start date';
  END IF;
END$$

CREATE TRIGGER trg_exhibition_before_update
BEFORE UPDATE ON EXHIBITION
FOR EACH ROW
BEGIN
  IF NEW.end_date < NEW.start_date THEN
    SIGNAL SQLSTATE '45000'
      SET MESSAGE_TEXT = 'Exhibition end date cannot be before start date';
  END IF;
END$$

CREATE FUNCTION fn_artifact_age(p_artifact_id INT)
RETURNS INT
READS SQL DATA
BEGIN
  DECLARE v_age INT;
  SELECT TIMESTAMPDIFF(YEAR, creation_date, CURDATE())
    INTO v_age FROM ARTIFACT WHERE artifact_id = p_artifact_id;
  RETURN v_age;
END$$

CREATE FUNCTION fn_total_restoration_cost(p_artifact_id INT)
RETURNS DECIMAL(12,2)
READS SQL DATA
BEGIN
  DECLARE v_total DECIMAL(12,2);
  SELECT COALESCE(SUM(cost), 0.00)
    INTO v_total FROM RESTORATION_PROJECT WHERE artifact_id = p_artifact_id;
  RETURN v_total;
END$$

CREATE PROCEDURE sp_artifacts_by_status(IN p_status VARCHAR(50))
BEGIN
  SELECT artifact_id, artifact_name, artifact_type, estimated_value, status
  FROM ARTIFACT WHERE status = p_status ORDER BY artifact_name;
END$$

CREATE PROCEDURE sp_artifact_restoration_projects(IN p_artifact_id INT)
BEGIN
  SELECT project_id, project_name, objective, start_date, end_date, status, cost
  FROM RESTORATION_PROJECT WHERE artifact_id = p_artifact_id ORDER BY start_date;
END$$

DELIMITER ;

CREATE OR REPLACE VIEW vw_artifact_catalogue AS
SELECT a.artifact_id, a.accession_number, a.artifact_name, a.artifact_type,
       a.status, a.estimated_value, c.collection_name, m.museum_name,
       cr.creator_name
FROM ARTIFACT a
JOIN COLLECTION c ON a.collection_id = c.collection_id
JOIN MUSEUM m ON c.museum_id = m.museum_id
LEFT JOIN CREATOR cr ON a.creator_id = cr.creator_id;
