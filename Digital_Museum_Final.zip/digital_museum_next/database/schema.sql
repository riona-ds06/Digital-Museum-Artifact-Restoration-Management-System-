-- Digital Museum DB : schema (DDL)
-- Changes vs. the original script: birth_year is INT from the start, CREATOR/EXHIBITION/ARTIFACT_MEDIA
-- ids are AUTO_INCREMENT, and the link tables (DISPLAY, PROJECT_EXPERT, PROJECT_MATERIAL) have composite primary keys.

CREATE TABLE MUSEUM (
    museum_id INT AUTO_INCREMENT,
    museum_name VARCHAR(150) NOT NULL,
    description TEXT,
    address VARCHAR(255),
    city VARCHAR(100),
    state VARCHAR(100),
    country VARCHAR(100),
    contact_email VARCHAR(150),
    contact_phone VARCHAR(30),
    established_year YEAR,
    PRIMARY KEY (museum_id)
);

CREATE TABLE COLLECTION (
    collection_id INT AUTO_INCREMENT,
    museum_id INT NOT NULL,
    collection_name VARCHAR(150) NOT NULL,
    description TEXT,
    historical_period VARCHAR(100),
    collection_type VARCHAR(100),
    date_created DATE,
    PRIMARY KEY (collection_id),
    CONSTRAINT fk_collection_museum FOREIGN KEY (museum_id) REFERENCES MUSEUM(museum_id)
        ON UPDATE CASCADE ON DELETE CASCADE
);

CREATE TABLE CREATOR (
    creator_id INT AUTO_INCREMENT,
    creator_name VARCHAR(150) NOT NULL,
    birth_year INT,
    nationality VARCHAR(100),
    biography TEXT,
    PRIMARY KEY (creator_id)
);

CREATE TABLE ARTIFACT (
    artifact_id INT AUTO_INCREMENT,
    collection_id INT NOT NULL,
    creator_id INT,
    accession_number VARCHAR(100) NOT NULL,
    artifact_name VARCHAR(200) NOT NULL,
    description TEXT,
    artifact_type VARCHAR(100),
    origin_place VARCHAR(150),
    creation_date DATE,
    estimated_value DECIMAL(15,2),
    acquisition_date DATE,
    status VARCHAR(100),
    PRIMARY KEY (artifact_id),
    CONSTRAINT uq_artifact_accession UNIQUE (accession_number),
    CONSTRAINT fk_artifact_collection FOREIGN KEY (collection_id) REFERENCES COLLECTION(collection_id)
        ON UPDATE CASCADE ON DELETE RESTRICT,
    CONSTRAINT fk_artifact_creator FOREIGN KEY (creator_id) REFERENCES CREATOR(creator_id)
        ON UPDATE CASCADE ON DELETE SET NULL
);

CREATE TABLE STAFF (
    staff_id INT AUTO_INCREMENT,
    staff_name VARCHAR(150) NOT NULL,
    email VARCHAR(150) NOT NULL,
    phone VARCHAR(30),
    designation VARCHAR(100),
    department VARCHAR(100),
    username VARCHAR(100) NOT NULL,
    password_hash VARCHAR(255) NOT NULL,
    staff_status VARCHAR(50) DEFAULT 'Active',
    role ENUM('ADMIN','STAFF') NOT NULL DEFAULT 'STAFF',
    PRIMARY KEY (staff_id),
    CONSTRAINT uq_staff_email UNIQUE (email),
    CONSTRAINT uq_staff_username UNIQUE (username)
);

CREATE TABLE EXHIBITION (
    exhibition_id INT AUTO_INCREMENT,
    museum_id INT NOT NULL,
    exhibition_name VARCHAR(200) NOT NULL,
    description TEXT,
    theme VARCHAR(150),
    start_date DATE,
    end_date DATE,
    status VARCHAR(50),
    PRIMARY KEY (exhibition_id),
    CONSTRAINT fk_exhibition_museum FOREIGN KEY (museum_id) REFERENCES MUSEUM(museum_id)
        ON UPDATE CASCADE ON DELETE CASCADE
);

CREATE TABLE DISPLAY (
    exhibition_id INT NOT NULL,
    artifact_id INT NOT NULL,
    display_start_date DATE,
    display_end_date DATE,
    display_location VARCHAR(150),
    display_case VARCHAR(100),
    display_notes TEXT,
    PRIMARY KEY (exhibition_id, artifact_id),
    CONSTRAINT fk_display_exhibition FOREIGN KEY (exhibition_id) REFERENCES EXHIBITION(exhibition_id)
        ON UPDATE CASCADE ON DELETE CASCADE,
    CONSTRAINT fk_display_artifact FOREIGN KEY (artifact_id) REFERENCES ARTIFACT(artifact_id)
        ON UPDATE CASCADE ON DELETE CASCADE
);

CREATE TABLE ARTIFACT_MEDIA (
    media_id INT AUTO_INCREMENT,
    artifact_id INT NOT NULL,
    staff_id INT,
    media_type VARCHAR(50),
    file_name VARCHAR(255),
    file_url VARCHAR(500),
    description TEXT,
    uploaded_on DATETIME DEFAULT CURRENT_TIMESTAMP,
    file_size BIGINT,
    PRIMARY KEY (media_id),
    CONSTRAINT fk_media_artifact FOREIGN KEY (artifact_id) REFERENCES ARTIFACT(artifact_id)
        ON UPDATE CASCADE ON DELETE CASCADE,
    CONSTRAINT fk_media_staff FOREIGN KEY (staff_id) REFERENCES STAFF(staff_id)
        ON UPDATE CASCADE ON DELETE SET NULL
);

CREATE TABLE ARTIFACT_HISTORY (
    history_id INT AUTO_INCREMENT,
    artifact_id INT NOT NULL,
    staff_id INT,
    event_date DATE NOT NULL,
    event_type VARCHAR(100),
    location VARCHAR(150),
    description TEXT,
    source_reference VARCHAR(500),
    PRIMARY KEY (history_id),
    CONSTRAINT fk_history_artifact FOREIGN KEY (artifact_id) REFERENCES ARTIFACT(artifact_id)
        ON UPDATE CASCADE ON DELETE CASCADE,
    CONSTRAINT fk_history_staff FOREIGN KEY (staff_id) REFERENCES STAFF(staff_id)
        ON UPDATE CASCADE ON DELETE SET NULL
);

CREATE TABLE RESTORATION_PROJECT (
    project_id INT AUTO_INCREMENT,
    artifact_id INT NOT NULL,
    manager_id INT,
    project_name VARCHAR(200) NOT NULL,
    objective TEXT,
    start_date DATE,
    end_date DATE,
    status VARCHAR(50),
    cost DECIMAL(15,2),
    PRIMARY KEY (project_id),
    CONSTRAINT fk_project_artifact FOREIGN KEY (artifact_id) REFERENCES ARTIFACT(artifact_id)
        ON UPDATE CASCADE ON DELETE CASCADE,
    CONSTRAINT fk_project_manager FOREIGN KEY (manager_id) REFERENCES STAFF(staff_id)
        ON UPDATE CASCADE ON DELETE SET NULL
);

CREATE TABLE CONDITION_ASSESSMENT (
    assessment_id INT AUTO_INCREMENT,
    artifact_id INT NOT NULL,
    staff_id INT,
    assessment_date DATE NOT NULL,
    conditions VARCHAR(100),
    damage_type VARCHAR(100),
    damage_description TEXT,
    recommended_action TEXT,
    priority VARCHAR(50),
    PRIMARY KEY (assessment_id),
    CONSTRAINT fk_assessment_artifact FOREIGN KEY (artifact_id) REFERENCES ARTIFACT(artifact_id)
        ON UPDATE CASCADE ON DELETE CASCADE,
    CONSTRAINT fk_assessment_staff FOREIGN KEY (staff_id) REFERENCES STAFF(staff_id)
        ON UPDATE CASCADE ON DELETE SET NULL
);

CREATE TABLE RESTORATION_EXPERT (
    expert_id INT AUTO_INCREMENT,
    expert_name VARCHAR(150) NOT NULL,
    email VARCHAR(150),
    phone VARCHAR(30),
    hours_worked DECIMAL(8,2),
    PRIMARY KEY (expert_id)
);

CREATE TABLE PROJECT_EXPERT (
    project_id INT NOT NULL,
    expert_id INT NOT NULL,
    PRIMARY KEY (project_id, expert_id),
    CONSTRAINT fk_project_expert_project FOREIGN KEY (project_id) REFERENCES RESTORATION_PROJECT(project_id)
        ON UPDATE CASCADE ON DELETE CASCADE,
    CONSTRAINT fk_project_expert_expert FOREIGN KEY (expert_id) REFERENCES RESTORATION_EXPERT(expert_id)
        ON UPDATE CASCADE ON DELETE CASCADE
);

CREATE TABLE RESTORATION_MATERIAL (
    material_id INT AUTO_INCREMENT,
    material_name VARCHAR(150) NOT NULL,
    material_type VARCHAR(100),
    supplier VARCHAR(150),
    unit VARCHAR(50),
    unit_cost DECIMAL(12,2),
    quantity_used DECIMAL(10,2),
    total_cost DECIMAL(15,2),
    PRIMARY KEY (material_id)
);

CREATE TABLE PROJECT_MATERIAL (
    project_id INT NOT NULL,
    material_id INT NOT NULL,
    PRIMARY KEY (project_id, material_id),
    CONSTRAINT fk_project_material_project FOREIGN KEY (project_id) REFERENCES RESTORATION_PROJECT(project_id)
        ON UPDATE CASCADE ON DELETE CASCADE,
    CONSTRAINT fk_project_material_material FOREIGN KEY (material_id) REFERENCES RESTORATION_MATERIAL(material_id)
        ON UPDATE CASCADE ON DELETE CASCADE
);

CREATE TABLE VISITOR (
    visitor_id INT AUTO_INCREMENT,
    visitor_name VARCHAR(150) NOT NULL,
    email VARCHAR(150),
    phone VARCHAR(30),
    age INT,
    nationality VARCHAR(100),
    registration_date DATE,
    PRIMARY KEY (visitor_id)
);

CREATE TABLE VISIT_RECORD (
    visit_id INT AUTO_INCREMENT,
    visitor_id INT NOT NULL,
    museum_id INT NOT NULL,
    visit_date DATE NOT NULL,
    entry_time TIME,
    exit_time TIME,
    visit_type VARCHAR(50),
    ticket_type VARCHAR(50),
    PRIMARY KEY (visit_id),
    CONSTRAINT fk_visit_visitor FOREIGN KEY (visitor_id) REFERENCES VISITOR(visitor_id)
        ON UPDATE CASCADE ON DELETE CASCADE,
    CONSTRAINT fk_visit_museum FOREIGN KEY (museum_id) REFERENCES MUSEUM(museum_id)
        ON UPDATE CASCADE ON DELETE CASCADE
);


-- Supporting indexes for common museum searches and joins.
CREATE INDEX idx_artifact_name ON ARTIFACT(artifact_name);
CREATE INDEX idx_artifact_status_type ON ARTIFACT(status, artifact_type);
CREATE INDEX idx_exhibition_dates ON EXHIBITION(start_date, end_date);
CREATE INDEX idx_visit_museum_date ON VISIT_RECORD(museum_id, visit_date);
CREATE INDEX idx_history_artifact_date ON ARTIFACT_HISTORY(artifact_id, event_date);
