
## MongoDB collections

The MongoDB Studio in the application supports five document collections:

- `artifact_research` — research findings, notes, tags, and references for artifacts.
- `conservation_observations` — flexible conservation/condition observations.
- `historical_references` — archival, bibliographic, and provenance references.
- `exhibition_feedback` — visitor feedback and ratings for exhibitions.
- `digital_documentation` — digital asset metadata, file details, and documentation records.

Sign in and open **MongoDB Studio**. Select a collection, enter a valid JSON object, and save it. The app adds `createdAt`, `updatedAt`, and `createdBy` automatically. Documents are listed from the selected collection. Example documents:

```json
{"title":"Bronze statue research","artifactId":101,"researcher":"Anita Rao","findings":["Possible 12th century origin"],"references":["Museum archive"]}
```

```json
{"artifactId":101,"observedBy":"Meera Nair","condition":"Stable","observations":["Minor surface dust","No visible cracks"],"severity":"Low"}
```

```json
{"artifactId":101,"sourceTitle":"Museum archive catalogue","author":"Collections team","year":2024,"url":"https://example.org/archive/101"}
```

```json
{"exhibitionId":1,"visitorName":"Optional","rating":5,"feedback":"Clear and informative display"}
```

```json
{"artifactId":101,"fileName":"bronze-statue-front.jpg","fileType":"image/jpeg","storagePath":"/museum-assets/101/front.jpg","dimensions":{"width":2400,"height":1600}}
```

The five MongoDB collections are created automatically when their first document is saved. MongoDB Studio accepts valid JSON documents so that each collection can hold fields appropriate to its document type. Existing MySQL tables and records are not modified by this feature.
