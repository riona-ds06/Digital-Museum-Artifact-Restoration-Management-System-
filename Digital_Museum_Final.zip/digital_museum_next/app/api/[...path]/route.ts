import { NextRequest, NextResponse } from "next/server";
import { pool, mongoCollection } from "@/lib/db";
import type { RowDataPacket, ResultSetHeader } from "mysql2";
import { currentUser } from "@/lib/auth";

export const runtime = "nodejs";
const allowed = ["MUSEUM","COLLECTION","CREATOR","ARTIFACT","STAFF","EXHIBITION","DISPLAY","ARTIFACT_MEDIA","ARTIFACT_HISTORY","RESTORATION_PROJECT","CONDITION_ASSESSMENT","RESTORATION_EXPERT","PROJECT_EXPERT","RESTORATION_MATERIAL","PROJECT_MATERIAL","VISITOR","VISIT_RECORD"];
const tableName = (s:string) => { const t=s.toUpperCase(); if (!allowed.includes(t)) throw new Error("Unknown table"); return t; };
const jsonError = (e:unknown, status=400) => NextResponse.json({error:e instanceof Error?e.message:"Request failed"}, {status});

export async function GET(req:NextRequest,{params}:{params:Promise<{path:string[]}>}) {
 try {
  const {path}=await params; const [area,arg]=path;
  if(area==="health") {
    await pool.query("SELECT 1");
    let mongo="not configured"; try { const c=await mongoCollection("healthcheck"); await c.findOne({}); mongo="connected"; } catch {}
    return NextResponse.json({mysql:"connected",mongodb:mongo});
  }
  const user=await currentUser(); if(!user) return NextResponse.json({error:"Please sign in to continue."},{status:401});
  if(area==="dashboard") {
   const [rows]=await pool.query<RowDataPacket[]>(`SELECT
    (SELECT COUNT(*) FROM MUSEUM) museums,(SELECT COUNT(*) FROM COLLECTION) collections,
    (SELECT COUNT(*) FROM ARTIFACT) artifacts,(SELECT COUNT(*) FROM CREATOR) creators,
    (SELECT COUNT(*) FROM STAFF) staff,(SELECT COUNT(*) FROM EXHIBITION) exhibitions,
    (SELECT COUNT(*) FROM EXHIBITION WHERE status='Active') active_exhibitions,
    (SELECT COUNT(*) FROM VISITOR) visitors,(SELECT COUNT(*) FROM VISIT_RECORD) visits,
    (SELECT COUNT(*) FROM RESTORATION_PROJECT) projects`);
   const [byStatus]=await pool.query("SELECT status label,COUNT(*) value FROM ARTIFACT GROUP BY status");
   const [top]=await pool.query("SELECT artifact_id,artifact_name,estimated_value,status FROM ARTIFACT ORDER BY estimated_value DESC LIMIT 5");
   return NextResponse.json({counts:rows[0],byStatus,top});
  }
  if(area==="artifacts") {
   const q=req.nextUrl.searchParams.get("q")||"", status=req.nextUrl.searchParams.get("status")||"";
   const [rows]=await pool.query<RowDataPacket[]>(`SELECT a.artifact_id,a.accession_number,a.artifact_name,a.artifact_type,a.status,a.estimated_value,c.collection_name,m.museum_name,cr.creator_name,
   fn_artifact_age(a.artifact_id) age_years,fn_total_restoration_cost(a.artifact_id) restoration_cost
   FROM ARTIFACT a JOIN COLLECTION c ON a.collection_id=c.collection_id JOIN MUSEUM m ON c.museum_id=m.museum_id
   LEFT JOIN CREATOR cr ON a.creator_id=cr.creator_id WHERE (?='' OR CONCAT_WS(' ',a.artifact_name,a.accession_number,a.artifact_type,cr.creator_name) LIKE ?)
   AND (?='' OR a.status=?) ORDER BY a.artifact_id`,[q,`%${q}%`,status,status]);
   return NextResponse.json(rows);
  }
  if(area==="tables") {
   if(user.role!=="ADMIN") return NextResponse.json({error:"Administrator access required to browse database tables."},{status:403});
   if(!arg) return NextResponse.json(allowed);
   const t=tableName(arg), [cols]=await pool.query<RowDataPacket[]>(`SHOW COLUMNS FROM \`${t}\``);
   const [rows]=await pool.query<RowDataPacket[]>(t==="STAFF"?`SELECT staff_id,staff_name,email,phone,designation,department,username,staff_status,role FROM \`${t}\` LIMIT 100`:`SELECT * FROM \`${t}\` LIMIT 100`);
   return NextResponse.json({table:t,columns:cols,rows});
  }
  if((area==="statuses"||area==="procedures") && user.role!=="ADMIN") return NextResponse.json({error:"Administrator access required for database features."},{status:403});
  if(area==="statuses") { const [r]=await pool.query("SELECT DISTINCT status FROM ARTIFACT WHERE status IS NOT NULL ORDER BY status"); return NextResponse.json(r); }
  if(area==="functions" && arg==="artifact-summary") {
   const artifactId=Number(req.nextUrl.searchParams.get("artifact_id"));
   if(!Number.isInteger(artifactId)||artifactId<1) return jsonError(new Error("Enter a valid artifact ID."));
   const [r]=await pool.query<RowDataPacket[]>(`SELECT a.artifact_id,a.artifact_name,fn_artifact_age(a.artifact_id) age_years,fn_total_restoration_cost(a.artifact_id) restoration_cost FROM ARTIFACT a WHERE a.artifact_id=?`,[artifactId]);
   if(!r.length) return jsonError(new Error("No artifact found with that ID."),404);
   return NextResponse.json(r[0]);
  }
  if(area==="procedures" && arg==="by-status") {
   const [r]=await pool.query("CALL sp_artifacts_by_status(?)",[req.nextUrl.searchParams.get("status")||""]); return NextResponse.json(r[0]);
  }
  if(area==="procedures" && arg==="restoration-projects") {
   const [r]=await pool.query("CALL sp_artifact_restoration_projects(?)",[Number(req.nextUrl.searchParams.get("artifact_id"))]); return NextResponse.json(r[0]);
  }
  if(area==="mongo") {
   const collection=req.nextUrl.searchParams.get("collection")||"artifact_research";
   const allowedMongo=["artifact_research","conservation_observations","historical_references","exhibition_feedback","digital_documentation"];
   if(!allowedMongo.includes(collection)) return jsonError(new Error("Unknown MongoDB collection."),400);
   const c=await mongoCollection(collection);
   await c.createIndex({createdAt:-1});
   if(collection!=="exhibition_feedback") await c.createIndex({artifactId:1});
   const docs=await c.find({}).sort({createdAt:-1}).limit(100).toArray();
   return NextResponse.json(docs.map(d=>({...d,_id:String(d._id)})));
  }
  if(area==="research") {
   const c=await mongoCollection("artifact_research");
   const docs=await c.find({}).sort({updatedAt:-1}).limit(100).toArray();
   return NextResponse.json(docs.map(d=>({...d,_id:String(d._id)})));
  }
  return jsonError(new Error("Endpoint not found"),404);
 } catch(e) { return jsonError(e); }
}

export async function POST(req:NextRequest,{params}:{params:Promise<{path:string[]}>}) {
 const conn=await pool.getConnection();
 try {
  const user=await currentUser(); if(!user) return NextResponse.json({error:"Please sign in to continue."},{status:401});
  const {path}=await params, body=await req.json();
  if(user.role!=="ADMIN" && !(path[0]==="research" || path[0]==="mongo")) return NextResponse.json({error:"Administrator access required for this action."},{status:403});
  if(path[0]==="demo" && path[1]==="material-trigger") {
   const name=String(body.material_name||"").trim(), type=String(body.material_type||"").trim(), supplier=String(body.supplier||"").trim(), unitName=String(body.unit||"").trim();
   const unit=Number(body.unit_cost), qty=Number(body.quantity_used), updatedQty=Number(body.updated_quantity);
   if(!name||!Number.isFinite(unit)||!Number.isFinite(qty)||!Number.isFinite(updatedQty)||unit<0||qty<0||updatedQty<0) return jsonError(new Error("Enter a material name and non-negative numeric cost and quantities."));
   await conn.beginTransaction();
   try {
    await conn.query("INSERT INTO RESTORATION_MATERIAL(material_name,material_type,supplier,unit,unit_cost,quantity_used,total_cost) VALUES(?,?,?,?,?,?,0)",[name,type||null,supplier||null,unitName||null,unit,qty]);
    const [first]=await conn.query<RowDataPacket[]>("SELECT material_id,total_cost FROM RESTORATION_MATERIAL WHERE material_id=LAST_INSERT_ID()");
    const insertTotal=Number(first[0].total_cost);
    await conn.query("UPDATE RESTORATION_MATERIAL SET quantity_used=? WHERE material_id=?",[updatedQty,first[0].material_id]);
    const [r]=await conn.query<RowDataPacket[]>("SELECT material_id,material_name,unit_cost,quantity_used,total_cost FROM RESTORATION_MATERIAL WHERE material_id=?",[first[0].material_id]);
    const updateTotal=Number(r[0].total_cost);
    await conn.rollback();
    return NextResponse.json({ok:true,row:r[0],insert_total:insertTotal,update_total:updateTotal,message:"INSERT and UPDATE triggers calculated total_cost from the submitted values. Demo row rolled back."});
   } catch(e) { await conn.rollback(); throw e; }
  }
  if(path[0]==="demo" && path[1]==="exhibition-trigger") {
   const museumId=Number(body.museum_id), name=String(body.exhibition_name||"").trim(), theme=String(body.theme||"").trim(), description=String(body.description||"").trim(), status=String(body.status||"Planned").trim();
   if(!Number.isInteger(museumId)||museumId<1||!name||!body.start_date||!body.end_date) return jsonError(new Error("Museum, exhibition name, start date and end date are required."));
   await conn.beginTransaction();
   let insertAccepted=true, updateAccepted=true, insertMessage="accepted", updateMessage="accepted";
   try {
    await conn.query("SAVEPOINT insert_test");
    try {
     await conn.query("INSERT INTO EXHIBITION(museum_id,exhibition_name,description,theme,start_date,end_date,status) VALUES(?,?,?,?,?,?,?)",[museumId,name,description,theme,body.start_date,body.end_date,status]);
    } catch(e) { insertAccepted=false; insertMessage=e instanceof Error?e.message:"Rejected by insert trigger"; await conn.query("ROLLBACK TO SAVEPOINT insert_test"); }
    await conn.query("INSERT INTO EXHIBITION(museum_id,exhibition_name,description,theme,start_date,end_date,status) VALUES(?,?,?,?,?,?,?)",[museumId,name+" (UPDATE TEST)",description,theme,"2026-01-01","2026-01-02","Planned"]);
    const [idRows]=await conn.query<RowDataPacket[]>("SELECT LAST_INSERT_ID() id");
    await conn.query("SAVEPOINT update_test");
    try { await conn.query("UPDATE EXHIBITION SET exhibition_name=?,description=?,theme=?,start_date=?,end_date=?,status=? WHERE exhibition_id=?",[name+" (UPDATE TEST)",description,theme,body.start_date,body.end_date,status,idRows[0].id]); }
    catch(e) { updateAccepted=false; updateMessage=e instanceof Error?e.message:"Rejected by update trigger"; await conn.query("ROLLBACK TO SAVEPOINT update_test"); }
    await conn.rollback();
    return NextResponse.json({accepted:insertAccepted&&updateAccepted,insertAccepted,updateAccepted,message:`INSERT trigger: ${insertAccepted?"accepted":insertMessage}. UPDATE trigger: ${updateAccepted?"accepted":updateMessage}. All temporary rows rolled back.`});
   } catch(e) { await conn.rollback(); throw e; }
  }
  if(path[0]==="mongo" || path[0]==="research") {
   const collection=path[0]==="research"?"artifact_research":String(body.collection||"artifact_research");
   const allowedMongo=["artifact_research","conservation_observations","historical_references","exhibition_feedback","digital_documentation"];
   if(!allowedMongo.includes(collection)) return jsonError(new Error("Unknown MongoDB collection."),400);
   const document=body.document;
   if(!document || typeof document!=="object" || Array.isArray(document)) return jsonError(new Error("Enter a valid JSON document."));
   const safe={...document};
   delete safe._id;
   if(!Object.keys(safe).length) return jsonError(new Error("The document cannot be empty."));
   safe.createdAt=new Date(); safe.updatedAt=new Date(); safe.createdBy=user.name;
   const c=await mongoCollection(collection);
   const result=await c.insertOne(safe);
   return NextResponse.json({ok:true,collection,id:String(result.insertedId)}, {status:201});
  }
  if(path[0]==="tables" && path[1]) {
   const t=tableName(path[1]), data=body.data||{};
   const [cols]=await conn.query<RowDataPacket[]>(`SHOW COLUMNS FROM \`${t}\``);
   const allowedCols=cols.map(c=>String(c.Field)).filter(c=>c!=="password_hash");
   const entries=Object.entries(data).filter(([k,v])=>allowedCols.includes(k)&&v!==undefined&&v!=="");
   if(!entries.length) return jsonError(new Error("No valid fields supplied."));
   const names=entries.map(([k])=>`\`${k}\``).join(",");
   const placeholders=entries.map(()=>"?").join(",");
   const [r]=await conn.query<ResultSetHeader>(`INSERT INTO \`${t}\` (${names}) VALUES (${placeholders})`,entries.map(([,v])=>v));
   return NextResponse.json({ok:true,insertId:r.insertId},{status:201});
  }
  return jsonError(new Error("Endpoint not found"),404);
 } catch(e) { return jsonError(e); } finally { conn.release(); }
}

export async function PUT(req:NextRequest,{params}:{params:Promise<{path:string[]}>}) {
 try {
  const user=await currentUser(); if(!user) return NextResponse.json({error:"Please sign in to continue."},{status:401});
  const {path}=await params, t=tableName(path[1]), body=await req.json(), key=body.key||{}, data=body.data||{};
  const staffEditable=["ARTIFACT_HISTORY","CONDITION_ASSESSMENT","ARTIFACT_MEDIA","RESTORATION_PROJECT"]; if(user.role!=="ADMIN" && !(staffEditable.includes(t))) return NextResponse.json({error:"You do not have permission to edit this table."},{status:403});
  const [cols]=await pool.query<RowDataPacket[]>(`SHOW COLUMNS FROM \`${t}\``);
  const pk=cols.filter(c=>c.Key==="PRI").map(c=>String(c.Field));
  if(!pk.length||pk.some(k=>key[k]===undefined)) return jsonError(new Error("Complete primary key is required."));
  const entries=Object.entries(data).filter(([k,v])=>cols.some(c=>c.Field===k)&&!pk.includes(k)&&k!=="password_hash"&&v!==undefined);
  if(!entries.length) return jsonError(new Error("No editable fields supplied."));
  const set=entries.map(([k])=>`\`${k}\`=?`).join(",");
  const where=pk.map(k=>`\`${k}\`=?`).join(" AND ");
  const [r]=await pool.query<ResultSetHeader>(`UPDATE \`${t}\` SET ${set} WHERE ${where}`,[...entries.map(([,v])=>v),...pk.map(k=>key[k])]);
  return NextResponse.json({ok:true,affectedRows:r.affectedRows});
 } catch(e) { return jsonError(e); }
}

export async function DELETE(req:NextRequest,{params}:{params:Promise<{path:string[]}>}) {
 try {
  const user=await currentUser(); if(!user) return NextResponse.json({error:"Please sign in to continue."},{status:401}); if(user.role!=="ADMIN") return NextResponse.json({error:"Administrator access required to delete records."},{status:403});
  const {path}=await params, t=tableName(path[1]), body=await req.json(), key=body.key||{};
  const [cols]=await pool.query<RowDataPacket[]>(`SHOW COLUMNS FROM \`${t}\``);
  const pk=cols.filter(c=>c.Key==="PRI").map(c=>String(c.Field));
  if(!pk.length||pk.some(k=>key[k]===undefined)) return jsonError(new Error("Complete primary key is required."));
  const [r]=await pool.query<ResultSetHeader>(`DELETE FROM \`${t}\` WHERE ${pk.map(k=>`\`${k}\`=?`).join(" AND ")}`,pk.map(k=>key[k]));
  return NextResponse.json({ok:true,deleted:r.affectedRows});
 } catch(e) { return jsonError(e); }
}
