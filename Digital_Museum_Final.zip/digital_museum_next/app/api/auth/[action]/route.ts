import {NextRequest,NextResponse} from "next/server";
import {pool} from "@/lib/db";
import {currentUser,signSession,sessionCookie} from "@/lib/auth";
import bcrypt from "bcryptjs";
import type {RowDataPacket,ResultSetHeader} from "mysql2";
export const runtime="nodejs";
export async function GET(_req:NextRequest,{params}:{params:Promise<{action:string}>}) { const {action}=await params; if(action!=="me")return NextResponse.json({error:"Not found"},{status:404}); const user=await currentUser(); return NextResponse.json({user}); }
export async function POST(req:NextRequest,{params}:{params:Promise<{action:string}>}) {
 const {action}=await params; const body=await req.json();
 try {
  if(action==="login") { const username=String(body.username||"").trim(),password=String(body.password||""); const [rows]=await pool.query<RowDataPacket[]>("SELECT staff_id,staff_name,email,username,password_hash,role,staff_status FROM STAFF WHERE username=? OR email=? LIMIT 1",[username,username]); const row=rows[0]; if(!row||row.staff_status==="Inactive"||!(await bcrypt.compare(password,row.password_hash)))return NextResponse.json({error:"Invalid username/email or password."},{status:401}); const user={staffId:Number(row.staff_id),name:row.staff_name,email:row.email,role:row.role as "ADMIN"|"STAFF"}; const res=NextResponse.json({user}); res.cookies.set(sessionCookie(signSession(user))); return res; }
  if(action==="logout") { const res=NextResponse.json({ok:true});res.cookies.set({name:"museum_session",value:"",httpOnly:true,path:"/",maxAge:0});return res; }
  if(action==="setup") { const [count]=await pool.query<RowDataPacket[]>("SELECT COUNT(*) total FROM STAFF WHERE role='ADMIN'"); if(Number(count[0].total)>0)return NextResponse.json({error:"An administrator is already configured. Ask an administrator to create your account."},{status:409}); if(!process.env.SETUP_SECRET||body.setupSecret!==process.env.SETUP_SECRET)return NextResponse.json({error:"Invalid setup secret."},{status:403}); const name=String(body.name||"").trim(),email=String(body.email||"").trim(),username=String(body.username||"").trim(),password=String(body.password||""); if(!name||!email||!username||password.length<12)return NextResponse.json({error:"Enter all fields and use a password of at least 12 characters."},{status:400}); const hash=await bcrypt.hash(password,12); const [r]=await pool.query<ResultSetHeader>("INSERT INTO STAFF(staff_name,email,username,password_hash,designation,department,staff_status,role) VALUES(?,?,?,?,'Administrator','Administration','Active','ADMIN')",[name,email,username,hash]); const user={staffId:r.insertId,name,email,role:"ADMIN" as const}; const res=NextResponse.json({user},{status:201});res.cookies.set(sessionCookie(signSession(user)));return res; }
  return NextResponse.json({error:"Not found"},{status:404});
 } catch(e) { return NextResponse.json({error:e instanceof Error?e.message:"Request failed"},{status:400}); }
}
