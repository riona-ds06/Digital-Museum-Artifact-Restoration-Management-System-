import type { Metadata } from "next";
import "./globals.css";
export const metadata:Metadata={title:"Digital Museum | Collections & Conservation",description:"Digital museum management and conservation workspace"};
export default function RootLayout({children}:{children:React.ReactNode}) {
 return <html lang="en"><body>{children}</body></html>;
}
