import mysql from "mysql2/promise";
import { MongoClient } from "mongodb";

const globalForDb = globalThis as unknown as { mysqlPool?: mysql.Pool; mongoClient?: MongoClient };
export const pool = globalForDb.mysqlPool ?? mysql.createPool({
  host: process.env.MYSQL_HOST, port: Number(process.env.MYSQL_PORT || 3306),
  user: process.env.MYSQL_USER, password: process.env.MYSQL_PASSWORD,
  database: process.env.MYSQL_DATABASE || "digital_museum_db",
  waitForConnections: true, connectionLimit: 10, decimalNumbers: true
});
if (process.env.NODE_ENV !== "production") globalForDb.mysqlPool = pool;

export async function mongoCollection(name: string) {
  if (!process.env.MONGODB_URI) throw new Error("MONGODB_URI is not configured");
  const client = globalForDb.mongoClient ?? new MongoClient(process.env.MONGODB_URI);
  if (!globalForDb.mongoClient) {
    await client.connect();
    if (process.env.NODE_ENV !== "production") globalForDb.mongoClient = client;
  }
  return client.db(process.env.MONGODB_DATABASE || "digital_museum").collection(name);
}
