import { cookies } from "next/headers";
import { createHmac, timingSafeEqual } from "node:crypto";

export type SessionUser = { staffId: number; name: string; email: string; role: "ADMIN" | "STAFF" };
const COOKIE = "museum_session";
function secret() { const value=process.env.SESSION_SECRET; if(!value || value.length<32) throw new Error("SESSION_SECRET must be set to a random value of at least 32 characters."); return value; }
export function signSession(user:SessionUser) { const payload=Buffer.from(JSON.stringify({...user,exp:Date.now()+8*60*60*1000})).toString("base64url"); const sig=createHmac("sha256",secret()).update(payload).digest("base64url"); return `${payload}.${sig}`; }
export function verifySession(token:string):SessionUser|null { try { const [payload,sig]=token.split("."); if(!payload||!sig)return null; const expected=createHmac("sha256",secret()).update(payload).digest(); const actual=Buffer.from(sig,"base64url"); if(actual.length!==expected.length||!timingSafeEqual(actual,expected))return null; const data=JSON.parse(Buffer.from(payload,"base64url").toString()); if(data.exp<Date.now()||!['ADMIN','STAFF'].includes(data.role))return null; return {staffId:data.staffId,name:data.name,email:data.email,role:data.role}; } catch { return null; } }
export async function currentUser() { const jar=await cookies(); const token=jar.get(COOKIE)?.value; return token?verifySession(token):null; }
export function sessionCookie(token:string) { return {name:COOKIE,value:token,httpOnly:true as const,sameSite:"lax" as const,secure:process.env.NODE_ENV==="production",path:"/",maxAge:8*60*60}; }
